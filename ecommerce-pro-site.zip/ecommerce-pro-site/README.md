# E-Ticaret Sitesi
Bu bir Next.js tabanlı basit e-ticaret sitesidir.